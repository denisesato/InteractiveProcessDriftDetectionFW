"""
The :mod:`skmultiflow.visualization` module includes visualization tools.
"""

from .evaluation_visualizer import EvaluationVisualizer

__all__ = ["EvaluationVisualizer"]
